// addEventListener > click sur btn "ajouter au panier" (récup id book)
// alerte > bien ajouté ! + redirection sur la page panier (?book= dans l'url)

